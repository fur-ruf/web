window.onload = function () {
    let canvasPrinter = new CanvasPrinter();
    canvasPrinter.redrawAll(document.querySelector("#R-input").value);

    document.getElementById("R-input")
    .onchange = function () {
        canvasPrinter.redrawAll(document.querySelector("#R-input").value);
    };

    $("#checkButton").on("click", function() {
        let jsonData = {
            "x": $("input[name='X-value']:checked").val(),
            "y": $("input[name='Y-value']").val(),
            "r": $("option[name='R-input']:selected").val()
        };

        if (isNaN(+jsonData.x) || isNaN(+jsonData.y) || isNaN(+jsonData.r) || +jsonData.y < -5 || +jsonData.y > 3) {
            alert(+jsonData.r);
            return;
        }

        $.ajax({
            url: "/fcgi-bin/?" + $.param(jsonData),
            type: "GET",
            dataType: "json",
            success: function(response) {
                if (response.error != null) {
                    alert("Ответ от сервера не получен");
                    console.log(response);
                } else {
                    $("#outputContainer").prepend($("<div></div>").text(response.exec_time + " ms"));
                    if (response.result) {
                        $("#outputContainer").prepend($("<div></div>").text("Да"));
                    } else {
                        $("#outputContainer").prepend($("<div></div>").text("Нет"));
                    }
                    $("#outputContainer").prepend($("<div></div>").text(jsonData.r));
                    $("#outputContainer").prepend($("<div></div>").text(jsonData.y));
                    $("#outputContainer").prepend($("<div></div>").text(jsonData.x));
                    $("#outputContainer").prepend($("<div></div>").text(response.current_time.split(" ")[1]));
                }
            },
            error: function(xhr, status, error) {
                alert(error)
            }
        });

        $.ajax({
            url: "/fcgi-bin/?" + $.param(jsonData),
            type: "POST",
            dataType: "json",
            success: function(response) {
                if (response.error != null) {
                    alert("Ответ от сервера не получен");
                    console.log(response);
                } else {
                    $("#outputContainer").prepend($("<div></div>").text(response.exec_time + " ms"));
                    if (response.result) {
                        $("#outputContainer").prepend($("<div></div>").text("Да"));
                    } else {
                        $("#outputContainer").prepend($("<div></div>").text("Нет"));
                    }
                    $("#outputContainer").prepend($("<div></div>").text(jsonData.r));
                    $("#outputContainer").prepend($("<div></div>").text(jsonData.y));
                    $("#outputContainer").prepend($("<div></div>").text(jsonData.x));
                    $("#outputContainer").prepend($("<div></div>").text(response.current_time.split(" ")[1]));
                }
            },
            error: function(xhr, status, error) {
                alert(error)
            }
        });
    })
};
